package com.majes.uottawa.taskmanager;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by Jeremie on 05-Dec-17.
 */


public class NoteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);


    }

    protected void cancelNote(){
        Intent returnIntent = new Intent();
        setResult(Activity.RESULT_CANCELED);
        finish();
    }

    protected void addNote(){
        TextView comment = (TextView) findViewById(R.id.noteComment);
        String comm = comment.getText().toString();
        Intent returnIntent = new Intent();
        returnIntent.putExtra("NOTE", comm);
        setResult(Activity.RESULT_OK);
    }
}
